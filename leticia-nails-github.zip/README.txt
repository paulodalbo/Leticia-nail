SITE — LETÍCIA NAILS (Gold Coast)
==================================

CONTEÚDO DA PASTA
- index.html        → o site (abra com duplo clique pra visualizar)
- images/           → todas as fotos reais do estúdio, otimizadas
    leticia-hero.jpg    (Letícia sorrindo — foto principal)
    leticia-sobre.jpg   (Letícia atendendo — seção "Sobre")
    salao-estacao.jpg   (estação de trabalho)
    salao-parede.jpg    (quadros + esmaltes)
    salao-plantas.jpg   (estação entre as plantas)
    salao-detalhe.jpg   (cantinho com cadeira verde)

JÁ ESTÁ TUDO PREENCHIDO COM OS DADOS REAIS
- WhatsApp: +61 403 784 417
- Instagram: @leticiasantosnails.aus
- Preços reais: BIAB $65 · Normal Polish (Mãos $45 / Pés $45 / Combo $80) ·
  Shellac $55 · Remoção $15 · French Tip +$5
- Tagline: "Beauty is in the details"

COMO PUBLICAR
Sobe a pasta inteira (index.html + a pasta images) pro seu serviço de
hospedagem. Mantém a pasta images dentro da mesma pasta do index.html,
senão as fotos não carregam.
Opções fáceis e gratuitas: Netlify (arrasta a pasta), Vercel, GitHub Pages.

TROCAR UMA FOTO
Substitua o arquivo dentro de images/ por outro com o MESMO nome.
Mantenha proporção parecida pra não distorcer (a hero e o "sobre" são
verticais 4:5; as do espaço podem ser variadas).

QUISER MUDAR ALGO NO TEXTO
Abra o index.html num editor de texto (ou me mande a mudança).
Os preços ficam na seção "Serviços & Valores"; os contatos no rodapé.

IDIOMA (EN / PT)
O site abre em INGLÊS por padrão (público principal da Gold Coast).
Tem um botão com globinho no menu que mostra "Português" — clicando,
o site inteiro troca pra português na hora, sem recarregar. Clicando de
novo volta pro inglês ("English").

Se você editar algum texto, lembre que ele existe em DOIS lugares:
- Português: direto no HTML (é o texto que aparece escrito lá).
- Inglês: no final do arquivo, no bloco "const EN = { ... }".
Cada texto tem uma etiqueta (ex.: hero_h1) que liga as duas versões.
Como o site abre em inglês, capriche principalmente na versão EN.

Dúvidas? É só chamar.
